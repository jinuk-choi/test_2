package egovframework.example.test.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.example.test.dao.TestDao;
import egovframework.example.test.domain.Board;
import egovframework.example.test.service.TestService;

@Service("testServiceImpl")
public class TestServiceImpl implements TestService	 {

	@Autowired
	private TestDao testDAOService;
	
	@Override
	public List<Board> selectBoardList(Board board) throws Exception {		
		return testDAOService.selectBoardList(board);
	}
}
