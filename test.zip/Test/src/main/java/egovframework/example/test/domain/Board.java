package egovframework.example.test.domain;

public class Board {
	
	private static final long serialVersionUID = 1L;
	
	private String a_title;
	private String a_content;
	
	
	public String getA_content() {
		return a_content;
	}
	public void setA_content(String a_content) {
		this.a_content = a_content;
	}
	public String getA_title() {
		return a_title;
	}
	public void setA_title(String a_title) {
		this.a_title = a_title;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
