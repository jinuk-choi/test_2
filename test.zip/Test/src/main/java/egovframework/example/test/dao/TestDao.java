package egovframework.example.test.dao;

import java.util.List;

import egovframework.example.test.domain.Board;

public interface TestDao {
	List<Board> selectBoardList(Board board) throws Exception;
}
