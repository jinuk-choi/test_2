package egovframework.example.test.service;


import java.util.List;

import egovframework.example.test.domain.Board;

public interface TestService {
	public List<Board> selectBoardList(Board board) throws Exception;
}
