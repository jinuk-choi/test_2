package com.lcomputerstudy.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LStudyRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
